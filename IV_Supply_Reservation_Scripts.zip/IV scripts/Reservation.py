import requests
import json
import copy
configFile = open('config\package.json')
configJson=json.loads(configFile.read())
configFile.close()

sampleJson = {  
   "lines":[  
      {  
         "deliveryMethod":"SHP",
         "distributionGroup":"dg_heavylift",
         "itemId":"34476532AQ_374_4",
         "lineId":"1",
         "productClass":"GOOD",
         "quantity":1.0,
         "shipNode":"HeavyLiftWH1",
         "unitOfMeasure":"EACH"
      }
   ],
   "reference":"",
   "segment":"",
   "segmentType":"",
   "timeToExpire":15
}
test=[None]*10
def CreateReservation(token,id):
	global test
	payload = {}
	url=configJson['reservation_url']
	"""for i in range(10):
		test[i] = copy.deepcopy(sampleJson)
		test[i]['itemId']="Item11"+str(i)"""
	#payload = test
	payload = copy.deepcopy(sampleJson)
	print(payload)
	headers = {
		'Content-Type': "application/json",
		'Authorization':""
		}
	headers['Authorization'] = "Bearer "+token
	response = requests.request("POST", url, data=json.dumps(sampleJson), headers=headers)
	#print("Response Status :"+response.status_code)
	print("Response: "+response.text)
	if(response.status_code > 400):
		raise Exception