from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session
import json
configFile = open('config\package.json')
configJson=json.loads(configFile.read())
configFile.close()
def GetToken():
	print(configJson['client_id'])
	client = BackendApplicationClient(client_id=configJson['client_id'])
	oauth = OAuth2Session(client=client)
	token = oauth.fetch_token(token_url=configJson['token_url'],client_id=configJson['client_id'],client_secret=configJson['client_secret'])
	test = token
	#print(token['access_token'])
	#tokenFlag = True
	return(token['access_token'])