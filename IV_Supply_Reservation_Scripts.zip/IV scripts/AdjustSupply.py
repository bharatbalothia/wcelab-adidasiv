import requests
import json
import copy
import random
configFile = open('config\package.json')
configJson=json.loads(configFile.read())
configFile.close()

itemJson = {  
			 "adjustmentReason":"SHIPMENT",
			 "eta":"1900-01-01T00:00:00Z",
			 "itemId":"Item57",
			 "lineReference":" ",
			 "productClass":"GOOD",
			 "shipByDate":"2500-01-01T00:00:00Z",
			 "shipNode":"HeavyLiftWH1",
			 "sourceTs":"2016-12-05T17:14:37Z",
			 "type":"ONHAND",
			 "unitOfMeasure":"EACH",
			  "quantity": 100.0,
		  }
test=[None]*5
def UpdateSupply(token,id):
	global test
	payload = {}
	url=configJson['supply_url']
	for i in range(5):
		test[i] = copy.deepcopy(itemJson)
		test[i]['itemId']="Item"+str(random.randint(1,200))
	payload['supplies'] = test
	print(payload)
	headers = {
		'Content-Type': "application/json",
		'Authorization':""
		}
	headers['Authorization'] = "Bearer "+token
	response = requests.request("PUT", url, data=json.dumps(payload), headers=headers)
	print(response.status_code)
	if(response.status_code > 400):
		raise Exception